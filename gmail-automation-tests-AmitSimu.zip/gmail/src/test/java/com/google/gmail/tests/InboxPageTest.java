package com.google.gmail.tests;

import java.io.IOException;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import com.google.gmail.webpages.InboxPage;
import com.google.gmail.webpages.LoginPage;

/***
 * This file tests functionalities of Inbox Page
 * 
 * @author Amit Simu
 * @FileName: InboxPageTest.java
 * 
 * 
 *
 */

public class InboxPageTest extends BaseTest{

	
	@Test
	public void verifyComposeEmail() throws IOException, InterruptedException
	{		
			String expectedSentMessageConfirmation = "Your message has been sent. View message";
			//AutoItScript autoitScript = new AutoItScript();
			WebDriverWait wait = new WebDriverWait(driver, 20);
			//AutoItX autoitScript = new AutoItX();
			LoginPage loginPage = new LoginPage(driver);
			loginPage.enterUserName("cp480863@gmail.com");
			loginPage.clickNextIdentifierId();
			driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
			loginPage.enterPassword("pass@1234");
			wait.until(ExpectedConditions.elementToBeClickable(loginPage.getPasswordNextBtnElement()));
			InboxPage inboxPage = loginPage.clickPasswordNextButton();
			inboxPage.clickComposeButton();
			wait.until(ExpectedConditions.visibilityOf(inboxPage.getRecepientEmailElement()));
			inboxPage.setRecepientEmailAddress("cp480863@gmail.com");
			inboxPage.setSubject("Test File");
			inboxPage.setBodyOfEmail("Test Email Body");
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			//inboxPage.clickFileAttachmentButton();
			//System.out.println("Clicked File Attachment ");
			
			String workingDirectory = System.getProperty("user.dir");
			System.out.println(workingDirectory);
			//String autoItScriptPath = workingDirectory+"\\scripts\\fileupload.exe";
			
			//Runtime.getRuntime().exec("D:\\Work\\WSp\\gmail\\scripts\\fileupload.exe");
			
			inboxPage.clickSendMail();
			wait.until(ExpectedConditions.visibilityOf(inboxPage.getSentEmailMessageElement()));
			Assert.assertEquals(inboxPage.getSentEmailMessage(), expectedSentMessageConfirmation);
		
		
	}
	
}
