package com.google.gmail.tests;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

/***
 * 
 * @FileName: BaseTest.java
 * TestNG framework to setup Before and After methods
 * 
 * @author Amit Simu
 *
 */
public abstract class BaseTest {
	
	public String url = "http://gmail.com";	
	protected static WebDriver driver;
	
	
	
	@BeforeTest
	public void initializeDriver()
	{
		
		String filePathToSet = System.getProperty("user.dir");
		System.out.println(filePathToSet);
		System.setProperty("webdriver.chrome.driver", filePathToSet+"\\Drivers\\chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
		options.addArguments("disable-infobars");
		driver=new ChromeDriver(options);
		
	//	driver = new ChromeDriver();
		driver.manage().window().maximize();
		
		driver.manage().deleteAllCookies();
		driver.get(url);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
	
	}	
	
	
	@AfterTest
		public void tearDown()
		{
			
			
			driver.quit();
		}
	
	
}
