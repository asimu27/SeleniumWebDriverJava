package com.google.gmail.tests;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;
import com.google.gmail.extensions.WebElementExtensions;
import com.google.gmail.webpages.InboxPage;
import com.google.gmail.webpages.LoginPage;
import junit.framework.Assert;

/***
 * This file tests the functionalities of Login Page
 * 
 * @author Amit Simu
 * @File LoginPageTest.java
 *
 */
public class LoginPageTest extends BaseTest{
	
	
	
	//WebDriverWait wait = new WebDriverWait(driver, 15);
	String expectedInboxPageTitle ="cp480863@gmail.com";
	WebElementExtensions webElementExtensions = new WebElementExtensions();

	@Test (priority=1)
	public void verifyEmailFieldIsPresent() throws Exception
	{

		LoginPage loginPage = new LoginPage(driver);	
		webElementExtensions.assertElementPresent(loginPage.getTxtIdentifierIdElement());
	}
	
	
	
	@Test (priority=2)
	public void verifyPasswordFieldIsPresent() throws Exception {
		LoginPage loginPage = new LoginPage(driver);
		loginPage.enterUserName("cp480863@gmail.com");
		loginPage.clickNextIdentifierId();
		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		webElementExtensions.assertElementPresent(loginPage.getTxtPasswordElement());
		
		
	}
	
	@Test(priority=3)
	public void verifyPasswordNextBtnIsPresent() throws Exception {
		LoginPage loginPage = new LoginPage(driver);
		loginPage.enterUserName("cp480863@gmail.com");
		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		loginPage.clickNextIdentifierId();
		
		loginPage.enterPassword("pass@1234");
		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		webElementExtensions.assertElementPresent(loginPage.getPasswordNextBtnElement());
		
	}
	
		
		@Test(priority=4)
		public void verifyLoginSuccessful(){
			WebDriverWait wait = new WebDriverWait(driver, 20);
			LoginPage loginPage = new LoginPage(driver);
			loginPage.enterUserName("cp480863@gmail.com");
			loginPage.clickNextIdentifierId();
			driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
			loginPage.enterPassword("pass@1234");
			wait.until(ExpectedConditions.elementToBeClickable(loginPage.getPasswordNextBtnElement()));
			InboxPage inboxPage = loginPage.clickPasswordNextButton();
			wait.until(ExpectedConditions.titleContains(expectedInboxPageTitle));
			Assert.assertEquals(expectedInboxPageTitle, inboxPage.getTitleOfInboxPage());		
			System.out.println("Login Successful");
		}
		
		
		
		@Test(priority=5)
		public void verifyLoginUnsuccessful(){
			WebDriverWait wait = new WebDriverWait(driver, 20);
			LoginPage loginPage = new LoginPage(driver);
			loginPage.enterUserName("cp480863@gmail.com");
			loginPage.clickNextIdentifierId();
			driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
			loginPage.enterPassword("pass@2234");
			//loginPage.clickPasswordNextButton();
			wait.until(ExpectedConditions.elementToBeClickable(loginPage.getPasswordNextBtnElement()));
			InboxPage inboxPage = loginPage.clickPasswordNextButton();
			
			wait.until(ExpectedConditions.textToBePresentInElement(loginPage.getElementOfErrMsgForInvalidPassword(), loginPage.getErrorMessageForInvalidPassword()));
			System.out.println("Login Failure");
		}
		
		
		
	}
	
	
	
	
	

	
	

