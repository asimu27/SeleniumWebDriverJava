package com.google.gmail.webpages;



import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import com.google.gmail.extensions.*;

/***
 * Page object file for Gmail Login Page. This file records the WebElements found on Login Page. Also, performs actions 
 * on the WebElements
 * 
 * @author Amit Simu
 *
 */

public class LoginPage extends BasePage{

	WebElementExtensions webElementExtensions = new WebElementExtensions();  
	
	@FindBy(how=How.XPATH, using="//*[@id='identifierId']")
	WebElement txtIdentifierId;
	
	@FindBy(how=How.XPATH, using="//*[@id='identifierNext']/content/span")
	WebElement btnNextIdentifier;
	
	@FindBy(how=How.XPATH, using="//*[@id='password']/div[1]/div/div[1]/input")
	WebElement txtPassword;
	
	@FindBy(how=How.XPATH, using="//*[@id='passwordNext']/content/span")
	WebElement btnNextPassword;
	
	@FindBy(how=How.XPATH, using="//*[@id='password']/div[2]/div[2]")
	WebElement txtErrMsgLoginUnsuccessful; 
	
	//Constructor to initialize WebDriver
	public LoginPage(WebDriver driver) {
		super(driver);
		PageFactory.initElements(driver, this);
	}
	
	public String getErrorMessageForInvalidPassword()
	{
		
		return txtErrMsgLoginUnsuccessful.getText();
	}
	
	
	public WebElement getElementOfErrMsgForInvalidPassword(){
		
		return txtErrMsgLoginUnsuccessful;
	}
		

	public WebElement getTxtIdentifierIdElement()
	{
		
		return txtIdentifierId;
		
	}
	
	public WebElement getPasswordNextBtnElement()
	{
		
		return btnNextPassword;
	}
	
	public WebElement getBtnIdentifierId()
	{
		
		return btnNextIdentifier;
	}
	
	
	public void enterUserName(String userName)
	{
		
		txtIdentifierId.sendKeys(userName);
		
	}
	
	public void enterPassword(String password)
	{
		txtPassword.sendKeys(password);
	
	}
	
	public void clickNextIdentifierId()
	{
		
		btnNextIdentifier.click();
		
	}
	
	public InboxPage clickPasswordNextButton()
	{
		
		btnNextPassword.click();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		
		return new InboxPage(driver);
	}

	public WebElement getTxtPasswordElement() {
		
		return txtPassword;
	}

}
