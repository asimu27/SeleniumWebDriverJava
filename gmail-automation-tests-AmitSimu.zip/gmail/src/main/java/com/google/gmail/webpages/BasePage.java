package com.google.gmail.webpages;

import org.openqa.selenium.WebDriver;


/***
 * This is an abstract class to initialize WebDriver
 * 
 * @author Amit Simu
 *
 */
public abstract class BasePage {

	
	protected WebDriver driver;
	
	public BasePage(WebDriver driver)
	{
		
		this.driver = driver;
	}
}
