package com.google.gmail.webpages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/***
 * Page Object file for Gmail Inbox Page. This file records the WebElements found on the login page 
 * and performs actions on them
 * 
 * @author Amit Simu
 *
 */

public class InboxPage extends BasePage {
	
	
	@FindBy(how= How.XPATH, using="//div[@role='button' and contains(text(), 'COMPOSE')]")
	WebElement btnCompose;
	
	//@FindBy(how=How.XPATH, using="//*[@id=':8y']")
	@FindBy(how=How.XPATH, using="//textarea[@class='vO' and @name='to']")
	WebElement txtRecepientEmailAddress;
	
	@FindBy(how=How.XPATH, using="//input[@name='subjectbox']")
	WebElement txtEmailSubject;
	
	@FindBy(how=How.XPATH, using="//*[@class='Am Al editable LW-avf' and @aria-label='Message Body']")
	WebElement txtEmailBody;
	
	@FindBy(how=How.XPATH, using="//div[@data-tooltip='Attach files']//div[@class='a1 aaA aMZ']")
	WebElement btnAttachment;
	
	@FindBy(how=How.XPATH, using="//div[contains(text(), 'Send')]")
	WebElement btnSendEmail;
	
	@FindBy(how=How.XPATH, using="//*[@class='vh' and contains(text(), 'Your message has been sent.')]")
	WebElement lblMessageSent;
	
	//Constructor to initialize the webdriver
	public InboxPage(WebDriver driver)
		{
	
			super(driver);
			PageFactory.initElements(driver, this);
	
		}
	
	public WebElement getSentEmailMessageElement()
		{
		
			return lblMessageSent;
		}
	
	
	public String getSentEmailMessage()
		{
		
			return lblMessageSent.getText();
		}
	
	
	public void clickSendMail()
		{
		
			btnSendEmail.click();
		}
	
	public WebElement getRecepientEmailElement()
		{
		
			return txtRecepientEmailAddress;
		}
	
	
	public WebElement getComposeButtonElement()
		{
		
			return btnCompose;
		}
	
	public void clickComposeButton()
		{
		
		
			btnCompose.click();
		}
	
	
	
	public void clickFileAttachmentButton()
		{
		
			btnAttachment.click();
		}
	
	
	public void setRecepientEmailAddress(String emailAddress)
		{
		
			txtRecepientEmailAddress.sendKeys(emailAddress);
		}
	
	public void setSubject(String emailSubject)
		{
		
			txtEmailSubject.sendKeys(emailSubject);
		
		}
	
	
	public void setBodyOfEmail(String emailText)
		{
		
			txtEmailBody.sendKeys(emailText);
		}
	
	
	
	
	public String getTitleOfInboxPage()
		{
		
			String str1 = driver.getTitle();
			String str2 = str1.substring(12, 30);
			System.out.println(str2);
			return str2;
		}
	

}
