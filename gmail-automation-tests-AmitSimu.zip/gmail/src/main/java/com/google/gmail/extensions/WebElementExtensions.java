package com.google.gmail.extensions;

import org.openqa.selenium.WebElement;

/***
 * 
 * This is a generic class for validating Web Elements of Web Pages
 * 
 * 
 * 
 * @author Amit Simu
 *
 */


public class WebElementExtensions {
	
	// Generic class to validate WebElements
	

	
	public void assertElementPresent(WebElement element) throws Exception
	{
		//Verifies if WebElement is	present on webpages
		if(!isElementPresent(element))
		throw new Exception("Element Not Present");
	}
	
	
		public static boolean isElementPresent(WebElement element)
		{
			
			try {
				
				boolean ele = element.isDisplayed();
				System.out.println(element + " is present");
				return true;
				
		}
		
			catch (org.openqa.selenium.NoSuchElementException e){
				
				return false;
				
				
			}
	}

}
